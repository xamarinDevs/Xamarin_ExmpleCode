## Directory Services

The app uses the interface `IDirectoryService` to get information from services.

Two concrete implementations of that interface are provided:

1. `LdapDirectoryService` is able to talk through LDAP to 

