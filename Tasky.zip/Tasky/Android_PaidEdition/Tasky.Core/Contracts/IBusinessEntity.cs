using System;

namespace Tasky.Core.Contracts {
	public interface IBusinessEntity {
		int ID { get; set; }
	}
}

