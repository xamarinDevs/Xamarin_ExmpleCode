README
------

The FREE edition of Xamarin has some limitations that are outlined at https://store.xamarin.com/

To provide the best getting-started experience possible, we provide two versions of the Tasky app:

* Starter - XML-based data store that runs on the FREE edition.

* Paid - SQLite-based database that can be run with a trial, Indie, Business or Enterprise license.


Visit the 10 minute guide for each platform to help you get started:

* Android - http://xamarin.com/getting-started/android

* iOS - http://xamarin.com/getting-started/ios

